"""
Marvick Felix
Program: Takes user input and converts kilometers to nautical miles
"""
#1 kilometer is equal to .539957 of a nautical mile
conversion = 0.539957

# Taking kilometers input from user

kilometers = float(input("Enter the value in kilometers: "))

#calculate miles

miles = kilometers * conversion
print('%0.2f kilometers is equal to %0.2f miles' %(kilometers,miles))


