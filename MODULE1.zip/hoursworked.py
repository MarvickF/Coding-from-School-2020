"""
Marvick Felix
Program: Takes users hourly wage, total regular hours, and total overtime hours
and displays an employee's total weekly pay
"""

wage = float(input("Enter hourly wage: "))
reghours = float(input("Enter regular hours worked: "))
overtime = float(input("Enter over time hours worked: "))

otwage = (wage*1.5)*overtime
regwage = wage * reghours
totalpay = regwage + otwage


print("This week total pay is",totalpay)
