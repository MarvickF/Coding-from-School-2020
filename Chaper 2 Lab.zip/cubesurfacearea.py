"""
Program: cubesurfacearea.py
Author: Marvick Felix
Computes surface area of a cube given lenth of 1 edge
"""

EDGE = int(input("Enter length of edge:"))
SURFACEAREA = 6*(EDGE*EDGE)
print("The surface area of this cube is", SURFACEAREA)
