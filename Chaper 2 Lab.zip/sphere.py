"""
Program: sphereradius.py
Author: Marvick Felix
Computes all measurements of a sphere given the radius as input
"""
import math
radius = float(input("What is the radius of the sphere?"))
diameter = 2 * radius
circumference = 2*math.pi*radius
surfacearea = 4*math.pi*(radius**2)
volume = 4/3 * math.pi * (radius**3)

print("The spheres diameter is",diameter,",the circumference is",circumference,
      "the surface area is",surfacearea,", and finally the volume is.",volume)

