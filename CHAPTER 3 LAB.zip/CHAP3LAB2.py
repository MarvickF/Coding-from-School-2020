"""
Marvick Felix
Question 2 for Lab Chapter 3
Program that detects whether or not a triangle is a right triangle
"""" 


print("Please input lengths of your triangles sides from shortest to longest")

c = float(input("C= "))
b = float(input("B= "))
a = float(input("A= "))

if (a**2 == b**2+c**2):
    print("Triangle is a right triangle")
else: print("Triangle is not a right triangle")
    
