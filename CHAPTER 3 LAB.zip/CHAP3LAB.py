"""
Marvick Felix
Lab for Chapter 3
Program that detects equilateral triangles
"""

print("Please input lengths of your triangles sides")
x = float(input("X= "))
y = float(input("Y= "))
z = float(input("Z= "))

if x == y == x:
    print("Equilateral triangle")
else:
        print("Not an equilateral triangle.")
